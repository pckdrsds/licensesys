I don’t know how to use sound.json files so please help me for these:

————————————————————————————————————

- Make the enderdragon play crit_hit.ogg instead of the normal hits when his HP is less than or equal to 50%

- play mobdeath.ogg right after a mob is killed. (When the poof particle shows up)

- play a entity/player/attack/strong.ogg attack when the player also uses the sweep attack

- Remove duplicate sounds and make them all refer to one.

- Remove slight pitch variation between identical files.

- When the trident is “pulled back, play “pullback.ogg”

- Remove the sound for ui/toast/out.ogg.

- Play heal.ogg when something gains any amount of HP.

- Stop boss music during the ender dragon’s death animation.

- play megalovania.ogg during wither boss fight. (Similar to ender dragon’s boss.ogg) make sure it is looped.

- play gameover.ogg client side when a user sees the respawn screen.

- play boss2.ogg instead of boss.ogg when enderdragon’s hp is less than or equal to 50%.

	If you would like to help with these, please refer to the unused files in /unused.

